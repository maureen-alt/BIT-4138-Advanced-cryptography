# week7_task1_differential.py

def simple_cipher_round(plaintext_byte: int, key_byte: int) -> int:
    """A basic mathematical function to simulate a single round configuration."""
    # Step 1: Key Mixing
    mixed = plaintext_byte ^ key_byte
    # Step 2: Dummy S-Box substitution lookup shift
    sbox = {i: (i * 3 + 7) % 256 for i in range(256)}
    return sbox[mixed]

def run_differential_simulation():
    print("--- Week 7: Practical Task 1 (Differential Simulation) ---")
    
    # Define a static test round key
    secret_key = 0b10110011 
    
    # Input two distinct but closely related integer values (1-bit difference)
    p1 = 0b01001000  # Character 'H'
    p2 = 0b01001001  # Character 'I'
    
    # Calculate initial input delta value
    input_xor_difference = p1 ^ p2
    
    # Pass both tracking values through the algorithm
    c1 = simple_cipher_round(p1, secret_key)
    c2 = simple_cipher_round(p2, secret_key)
    
    # Calculate output delta value
    output_xor_difference = c1 ^ c2
    
    # Display step-by-step diagnostic breakdown
    print(f"Plaintext 1 (P1)  : {p1:08b} (Decimal: {p1})")
    print(f"Plaintext 2 (P2)  : {p2:08b} (Decimal: {p2})")
    print(f"Input Difference   : {input_xor_difference:08b} <-- (XOR Delta)")
    print("-" * 50)
    print(f"Ciphertext 1 (C1) : {c1:08b} (Hex: {c1:02x})")
    print(f"Ciphertext 2 (C2) : {c2:08b} (Hex: {c2:02x})")
    print(f"Output Difference  : {output_xor_difference:08b} <-- (Propagated Delta)")

if __name__ == "__main__":
    run_differential_simulation()