# cryptanalysis_toolkit.py
"""
BIT4138: Advanced Cryptography
Practical Portfolio Component: Mini Cryptanalysis Toolkit (Zero-Dependency)
"""

import tkinter as tk
from tkinter import ttk, messagebox

class CryptanalysisSuite:
    @staticmethod
    def calculate_xor_difference(val1: int, val2: int) -> int:
        """Computes the bitwise XOR delta difference between two integer blocks."""
        return (val1 ^ val2) & 0xFF

    @staticmethod
    def perform_frequency_analysis(text_stream: str) -> dict:
        """Tracks occurrence rates of each unique token inside the target stream."""
        frequencies = {}
        for char in text_stream:
            frequencies[char] = frequencies.get(char, 0) + 1
        return frequencies

    @staticmethod
    def measure_statistical_bias(text_stream: str) -> float:
        """
        Measures the linear statistical bias of individual bits.
        In a perfectly random cipher space, the probability of any bit being 1 is 0.5.
        Bias = | (Count of 1s / Total Bits) - 0.5 |
        """
        total_bits = len(text_stream) * 8
        if total_bits == 0:
            return 0.0
            
        one_bits_count = 0
        for char in text_stream:
            byte_val = ord(char)
            one_bits_count += bin(byte_val).count('1')
            
        probability_of_ones = one_bits_count / total_bits
        linear_bias = abs(probability_of_ones - 0.5)
        return linear_bias


class ToolkitApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BIT4138: Mini Cryptanalysis Toolkit")
        # Direct structural configuration to prevent layout geometry parsing crashes
        self.geometry("780x600")
        self._build_ui()

    def _build_ui(self):
        notebook = ttk.Notebook(self)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)

        # --- TAB: TOOLKIT WORKSPACE ---
        workspace_tab = ttk.Frame(notebook)
        notebook.add(workspace_tab, text="Cryptanalysis Diagnostics Workspace")

        # 1. Differential Analysis Input Config
        diff_frame = ttk.LabelFrame(workspace_tab, text=" 1. Differential Analysis Configuration (XOR Deltas) ")
        diff_frame.pack(fill='x', padx=10, pady=8)

        ttk.Label(diff_frame, text="Plaintext Byte 1 (Hex 00-FF):").grid(row=0, column=0, padx=5, pady=8, sticky='w')
        self.txt_p1 = ttk.Entry(diff_frame, width=12)
        self.txt_p1.insert(0, "48")  # Character 'H'
        self.txt_p1.grid(row=0, column=1, padx=5, pady=8, sticky='w')

        ttk.Label(diff_frame, text="Plaintext Byte 2 (Hex 00-FF):").grid(row=0, column=2, padx=15, pady=8, sticky='w')
        self.txt_p2 = ttk.Entry(diff_frame, width=12)
        self.txt_p2.insert(0, "49")  # Character 'I'
        self.txt_p2.grid(row=0, column=3, padx=5, pady=8, sticky='w')

        # 2. Statistical Testing Input Stream Panel
        stat_frame = ttk.LabelFrame(workspace_tab, text=" 2. Statistical Stream Auditing (Frequency & Bias Sweeps) ")
        stat_frame.pack(fill='both', expand=True, padx=10, pady=8)

        ttk.Label(stat_frame, text="Target Ciphertext String / Core Cryptographic Bitstream Input:").pack(anchor='w', padx=10, pady=4)
        self.txt_stream = tk.Text(stat_frame, height=8, width=65, font=("Consolas", 10))
        self.txt_stream.insert("1.0", "A5B2C3A5F0E1A5B2C3FFF0A5B2C3D4E5A5B2C3A5A5")
        self.txt_stream.pack(fill='both', expand=True, padx=10, pady=8)

        # Control Execution Bar
        btn_run = ttk.Button(workspace_tab, text="📊 Run Diagnostics & Print Live Dashboard", command=self._execute_analysis)
        btn_run.pack(fill='x', padx=10, pady=12, ipady=6)

    def _execute_analysis(self):
        try:
            p1_val = int(self.txt_p1.get(), 16) & 0xFF
            p2_val = int(self.txt_p2.get(), 16) & 0xFF
        except ValueError:
            messagebox.showerror("Input Error", "Please verify that your plaintext byte configurations are valid Hex values.")
            return

        cipher_stream = self.txt_stream.get("1.0", "end-1c").strip()
        if not cipher_stream:
            messagebox.showwarning("Input Missing", "The target stream testing block cannot be empty.")
            return

        # 1. Differential Mapping Transformations
        input_xor_delta = CryptanalysisSuite.calculate_xor_difference(p1_val, p2_val)

        # Algorithmic step simulation modeling S-Box output byte mixing propagation 
        c1_mock = ((p1_val ^ 0x5F) * 3 + 7) & 0xFF
        c2_mock = ((p2_val ^ 0x5F) * 3 + 7) & 0xFF
        output_xor_delta = CryptanalysisSuite.calculate_xor_difference(c1_mock, c2_mock)

        # 2. Extract Character Frequencies
        freq_distribution = CryptanalysisSuite.perform_frequency_analysis(cipher_stream)

        # 3. Measure Linear Structural Bit Bias
        bias_metric = CryptanalysisSuite.measure_statistical_bias(cipher_stream)

        # Print structured metrics report down to the active VS Code Terminal stream
        print("\n" + "="*70)
        print("                BIT4138 - AUTOMATED CRYPTANALYSIS REPORT               ")
        print("="*70)
        
        print("\n[ TRACKING DIFFERENTIAL DELTA VECTORS ]")
        print("-" * 65)
        print(f"  Plaintext Byte 1 (P1)     : Bin {p1_val:08b} | Hex {p1_val:02x}")
        print(f"  Plaintext Byte 2 (P2)     : Bin {p2_val:08b} | Hex {p2_val:02x}")
        print(f"  Input XOR Delta Difference: {input_xor_delta:08b}")
        print(f"  Output XOR Delta Propagated: {output_xor_delta:08b}")

        print("\n[ EXTRACTING CHARACTER FREQUENCY ANALYSIS DISTRIBUTION ]")
        print("-" * 65)
        sorted_freqs = sorted(freq_distribution.items(), key=lambda x: x[1], reverse=True)
        for token, count in sorted_freqs[:6]:  # Output top distribution spikes
            bar_graph = "█" * count
            print(f"  Token Symbol '{token}' -> Occurrences: {count:<3} {bar_graph}")
            
        print("\n[ EVALUATING LINEAR STATISTICAL BIAS PROPERTIES ]")
        print("-" * 65)
        print(f"  Calculated Bit Bias Density Metric: {bias_metric:.5f}")
        if bias_metric > 0.05:
            print("  Result Warning: High Statistical Bias detected! Key leakage possible via approximation attacks.")
        else:
            print("  Result Secure: Balanced bit density profile. Strong uniform randomness characteristics.")
        print("="*70 + "\n")

        messagebox.showinfo("Success", "Cryptanalysis metrics printed successfully to your VS Code Terminal Tab!")


if __name__ == "__main__":
    app = ToolkitApp()
    app.mainloop()