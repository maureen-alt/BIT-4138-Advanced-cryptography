# block_cipher_analyzer.py
"""
BIT4138: Advanced Cryptography
Challenge Task: Block Cipher Security Analyzer (Zero-Dependency Version)
"""

import tkinter as tk
from tkinter import ttk, messagebox
import random

class MiniAESEngine:
    """A mathematically simplified, AES-inspired 8-bit block cipher engine."""
    def __init__(self):
        # 4-bit S-Box for substitution (confusion)
        self.sbox = [0xE, 0x4, 0xD, 0x1, 0x2, 0xF, 0xB, 0x8, 0x3, 0xA, 0x6, 0xC, 0x5, 0x9, 0x0, 0x7]
        self.sbox_inv = [self.sbox.index(x) for x in range(16)]

    def _add_round_key(self, block: int, round_key: int) -> int:
        """Applies bitwise XOR key mixing layer."""
        return (block ^ round_key) & 0xFF

    def _sub_nibbles(self, block: int, inverse: bool = False) -> int:
        """Splits an 8-bit block into two 4-bit nibbles and applies S-Box lookup."""
        lookup = self.sbox_inv if inverse else self.sbox
        upper_nibble = (block >> 4) & 0x0F
        lower_nibble = block & 0x0F
        return (lookup[upper_nibble] << 4) | lookup[lower_nibble]

    def _shift_rows(self, block: int) -> int:
        """Permutes internal data state by swapping nibbles to provide diffusion."""
        upper = (block >> 4) & 0x0F
        lower = block & 0x0F
        return (lower << 4) | upper

    def _generate_key_schedule(self, master_key: int, rounds: int) -> list:
        """Derives custom unique subkeys for each execution round."""
        subkeys = []
        for r in range(rounds + 1):
            rotated_key = ((master_key << r) | (master_key >> (8 - r))) & 0xFF
            subkeys.append(rotated_key)
        return subkeys

    def encrypt_block(self, plaintext_byte: int, master_key: int, total_rounds: int = 4) -> int:
        """Executes full multi-round encryption across a single 8-bit block."""
        round_keys = self._generate_key_schedule(master_key, total_rounds)
        state = plaintext_byte
        
        # Initial Key Mixing (Round 0)
        state = self._add_round_key(state, round_keys[0])
        
        # Core Transformational Rounds
        for r in range(1, total_rounds):
            state = self._sub_nibbles(state, inverse=False)
            state = self._shift_rows(state)
            state = self._add_round_key(state, round_keys[r])
            
        # Final Round (Omits final permutation to mirror AES design)
        state = self._sub_nibbles(state, inverse=False)
        state = self._add_round_key(state, round_keys[total_rounds])
        return state

    def decrypt_block(self, ciphertext_byte: int, master_key: int, total_rounds: int = 4) -> int:
        """Reverses round operations sequentially to recover plaintext."""
        round_keys = self._generate_key_schedule(master_key, total_rounds)
        state = ciphertext_byte
        
        state = self._add_round_key(state, round_keys[total_rounds])
        state = self._sub_nibbles(state, inverse=True)
        
        for r in range(total_rounds - 1, 0, -1):
            state = self._add_round_key(state, round_keys[r])
            state = self._shift_rows(state)
            state = self._sub_nibbles(state, inverse=True)
            
        state = self._add_round_key(state, round_keys[0])
        return state


class SecurityAnalyzerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BIT4138: Block Cipher Security Analyzer")
        # FIX: Compact formatting string with zero blank spaces to bypass Tkinter crash layout bugs
        self.geometry("750x600")
        self.engine = MiniAESEngine()
        self._build_ui()

    def _build_ui(self):
        notebook = ttk.Notebook(self)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # --- TAB 1: ENCRYPTION / DECRYPTION WORKSPACE ---
        workspace = ttk.Frame(notebook)
        notebook.add(workspace, text="Cipher Engine Workspace")
        
        # Parameters Frame
        param_frame = ttk.LabelFrame(workspace, text=" Cryptographic Configuration ")
        param_frame.pack(fill='x', padx=10, pady=10)
        
        ttk.Label(param_frame, text="Secret Key (Hex 00-FF):").grid(row=0, column=0, padx=5, pady=5)
        self.key_entry = ttk.Entry(param_frame, width=8)
        self.key_entry.insert(0, "A5")
        self.key_entry.grid(row=0, column=1, padx=5, pady=5)
        
        ttk.Label(param_frame, text="Rounds:").grid(row=0, column=2, padx=10, pady=5)
        self.rounds_box = ttk.Combobox(param_frame, values=["2", "4", "8"], width=4, state="readonly")
        self.rounds_box.set("4")
        self.rounds_box.grid(row=0, column=3, padx=5, pady=5)
        
        # Data Fields
        ttk.Label(workspace, text="Plaintext Input String:").pack(anchor='w', padx=10)
        self.txt_plain = tk.Text(workspace, height=5, width=60)
        self.txt_plain.insert("1.0", "Hello Cryptanalysis Portfolio!")
        self.txt_plain.pack(fill='x', padx=10, pady=5)
        
        btn_frame = ttk.Frame(workspace)
        btn_frame.pack(fill='x', padx=10, pady=5)
        ttk.Button(btn_frame, text="🔒 Encrypt", command=self._encrypt).pack(side='left', expand=True, fill='x', padx=2)
        ttk.Button(btn_frame, text="🔓 Decrypt", command=self._decrypt).pack(side='left', expand=True, fill='x', padx=2)
        
        ttk.Label(workspace, text="Ciphertext (Hex Stream):").pack(anchor='w', padx=10)
        self.txt_cipher = tk.Text(workspace, height=5, width=60)
        self.txt_cipher.pack(fill='x', padx=10, pady=5)

        # --- TAB 2: TERMINAL ANALYSIS RUNNER ---
        analysis_tab = ttk.Frame(notebook)
        notebook.add(analysis_tab, text="Security Analytics Dashboard")
        
        info_frame = ttk.LabelFrame(analysis_tab, text=" Cryptanalytic Suite Controls ")
        info_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        msg = ("This suite prints high-fidelity, zero-dependency ASCII dashboards directly to your "
               "VS Code TERMINAL tab to completely bypass local pip compiler glitches.\n\n"
               "Click the button below, then open your VS Code Terminal panel to view and "
               "screenshot your automated cryptanalysis charts.")
        
        lbl = ttk.Label(info_frame, text=msg, wraplength=650, justify='left', font=("Consolas", 11))
        lbl.pack(padx=20, pady=20)
        
        btn_run = ttk.Button(info_frame, text="📊 Run Cryptanalysis & Print Terminal Charts", command=self._run_diagnostics)
        btn_run.pack(pady=10, ipadx=10, ipady=5)

    def _get_params(self):
        try:
            return int(self.key_entry.get(), 16) & 0xFF, int(self.rounds_box.get())
        except ValueError:
            messagebox.showerror("Error", "Enter a valid Hex Key (e.g., A5)")
            return None, None

    def _encrypt(self):
        key, rnds = self._get_params()
        if key is None: return
        text = self.txt_plain.get("1.0", "end-1c")
        out = "".join(f"{self.engine.encrypt_block(ord(c), key, rnds):02x}" for c in text)
        self.txt_cipher.delete("1.0", "end")
        self.txt_cipher.insert("1.0", out)

    def _decrypt(self):
        key, rnds = self._get_params()
        if key is None: return
        hex_str = self.txt_cipher.get("1.0", "end-1c").strip()
        try:
            out = "".join(chr(self.engine.decrypt_block(int(hex_str[i:i+2], 16), key, rnds)) for i in range(0, len(hex_str), 2))
            self.txt_plain.delete("1.0", "end")
            self.txt_plain.insert("1.0", out)
        except Exception:
            messagebox.showerror("Error", "Malformed Hex Stream string data.")

    def _run_diagnostics(self):
        key, rnds = self._get_params()
        if key is None: return
        
        # 1. Calculate Avalanche Metrics Profile
        base_input = 0x41  # Char 'A'
        base_cipher = self.engine.encrypt_block(base_input, key, rnds)
        avalanche_data = []
        for b in range(8):
            mutated_input = base_input ^ (1 << b)
            mutated_cipher = self.engine.encrypt_block(mutated_input, key, rnds)
            avalanche_data.append(bin(base_cipher ^ mutated_cipher).count('1'))
            
        # 2. Difference Analysis Testing Simulation
        p1, p2 = 0x48, 0x49  # 'H' and 'I' (1-bit difference)
        in_delta = p1 ^ p2
        out_delta = self.engine.encrypt_block(p1, key, rnds) ^ self.engine.encrypt_block(p2, key, rnds)

        # 3. Frequency Sweep Distribution (1000 Cycles)
        freq_map = {}
        for _ in range(1000):
            rand_b = random.randint(0, 255)
            enc = self.engine.encrypt_block(rand_b, key, rnds)
            freq_map[enc] = freq_map.get(enc, 0) + 1

        # Print the Dashboard out to the terminal
        # FIX: Stray brackets removed to clean up reporting output layout
        print("\n" + "="*65)
        print("          BIT4138 - BLOCK CIPHER CRYPTANALYSIS DASHBOARD        ")
        print("="*65)
        print(f"Configurations Used: Master Key = 0x{key:02x} | Total Rounds = {rnds}")
        
        print("\n[ PANEL A: AVALANCHE EFFECT ATTACK TRACKING PROFILE ]")
        print("Ideal Target State Baseline: 4 Bits Swapped (50.0%)")
        print("-" * 65)
        for idx, bits in enumerate(avalanche_data):
            bar = "█" * bits
            print(f"  Flipped Plaintext Bit {idx} -> Output Bits Mutated: {bits} {bar:<8} ({(bits/8)*100:.1f}%)")
            
        print("\n[ PANEL B: DIFFERENTIAL CRYPTANALYSIS DELTA PROPAGATION ]")
        print("-" * 65)
        print(f"  Input Vector XOR Difference Delta  : {in_delta:08b}")
        print(f"  Output Vector XOR Propagation Delta : {out_delta:08b}")
        
        print("\n[ PANEL C: FREQUENCY DISTRIBUTION DENSITY METRICS ]")
        print("-" * 65)
        print(f"  Total Trial Allocations Tested : 1,000 Randomized Block Shifts")
        print(f"  Unique Cipher Space Byte Hits : {len(freq_map)} / 256 State Spaces")
        print(f"  Output Density Coverage Ratio  : {(len(freq_map)/256)*100:.1f}%")
        print("="*65 + "\n")
        
        messagebox.showinfo("Success", "Security metrics printed successfully to your VS Code Terminal Tab!")

if __name__ == "__main__":
    app = SecurityAnalyzerApp()
    app.mainloop()