"""
BIT4138: Advanced Cryptography
Practical Task 2 - Non-Linearity Investigation Verification Tool
Fixed: Corrected f-string format alignment specifiers for integer types.
"""

class NonLinearityInvestigator:
    def __init__(self):
        # 4-bit S-Box Lookup Table from curriculum mapping specifications
        self.sbox = {
            0x0: 0xE, 0x1: 0x4, 0x2: 0xD, 0x3: 0x1,
            0x4: 0x2, 0x5: 0xF, 0x6: 0xB, 0x7: 0x8,
            0x8: 0x3, 0x9: 0xA, 0xA: 0x6, 0xB: 0xC,
            0xC: 0x5, 0xD: 0x9, 0xE: 0x0, 0xF: 0x7
        }

    def evaluate_linearity(self):
        """
        Tests the S-Box against the strict linear condition: S(A ^ B) == S(A) ^ S(B)
        Traces variable combinations to calculate and display non-linearity strength.
        """
        linear_hits = 0
        non_linear_hits = 0
        total_tests = 0

        print("=" * 72)
        print("        S-BOX ALGEBRAIC NON-LINEARITY DISCOVERY MATRIX         ")
        print("=" * 72)
        # Using clear, readable headers matching our table columns
        print(f"{'Input A':<10}{'Input B':<10}{'S(A ^ B)':<15}{'S(A) ^ S(B)':<15}{'Is Linear?'}")
        print("-" * 72)

        # Iterate through all combinations of a 4-bit domain (0 to 15)
        for a in range(16):
            for b in range(16):
                # Skip the trivial case where b is 0
                if b == 0:
                    continue

                total_tests += 1
                
                # Evaluate Left Hand Side: S(A XOR B)
                lhs = self.sbox[a ^ b]
                
                # Evaluate Right Hand Side: S(A) XOR S(B)
                rhs = self.sbox[a] ^ self.sbox[b]
                
                is_linear = (lhs == rhs)
                
                if is_linear:
                    linear_hits += 1
                else:
                    non_linear_hits += 1

                # Display a clean sample slice of mappings to verify output layout
                if a < 3 and b < 4:
                    # FIX: Corrected format specifiers to use standard '{var:<widthX}' 
                    # This correctly prints as standard Hex while enforcing exact column padding widths
                    print(f"0x{a:<8X}0x{b:<8X}0x{lhs:<13X}0x{rhs:<13X}{str(is_linear):<10}")

        print("-" * 72)
        print(f" [*] Total Verification Checks Evaluated : {total_tests}")
        print(f" [*] Linear Conditions Found             : {linear_hits}")
        print(f" [*] Non-Linear Deviations Confirmed     : {non_linear_hits}")
        
        # Calculate non-linearity threshold ratio
        deviation_percentage = (non_linear_hits / total_tests) * 100
        print(f" [*] Total Non-Linearity Profile Strength: {deviation_percentage:.2f}%")
        print("-" * 72)
        
        if linear_hits == 0:
            print(" EVALUATION RESULT: SECURE - The S-Box is completely non-linear.")
            print(" Exploitable linear equations cannot be constructed against this layer.")
        else:
            print(" EVALUATION WARNING: LEAK DETECTED - S-Box contains partial linear bias.")
        print("=" * 72 + "\n")


if __name__ == "__main__":
    investigator = NonLinearityInvestigator()
    investigator.evaluate_linearity()