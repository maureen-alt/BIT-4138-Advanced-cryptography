"""
BIT4138: Advanced Cryptography
Unified Multi-Round SPN & Mini-AES Simulator Suite
Fixed Tkinter Loop Threading & Data Bounds Boundary Safety
"""

import tkinter as tk
from tkinter import ttk, messagebox

class AESInspiredEngine:
    def __init__(self):
        # 8-bit AES S-Box Array (256 distinct values)
        self.sbox = [
            0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
            0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
            0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
            0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
            0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
            0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
            0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
            0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
            0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
            0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
            0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
            0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
            0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
            0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
            0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
            0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
        ]
        self.sbox_inv = [self.sbox.index(x) for x in range(256)]

    def _key_mixing(self, state: list, r_key: int) -> list:
        return [b ^ r_key for b in state]

    def _sub_bytes(self, state: list, inv: bool = False) -> list:
        table = self.sbox_inv if inv else self.sbox
        return [table[b] for b in state]

    def _shift_rows(self, state: list, inv: bool = False) -> list:
        # Prevent any structural stalls on empty blocks or short buffers
        if len(state) < 4:
            return state[::-1]
        
        # Safe block chunk slicing mechanics
        res = list(state)
        for i in range(0, len(state), 4):
            chunk = state[i:i+4]
            if len(chunk) == 4:
                if not inv:
                    res[i:i+4] = [chunk[1], chunk[2], chunk[3], chunk[0]]
                else:
                    res[i:i+4] = [chunk[3], chunk[0], chunk[1], chunk[2]]
        return res

    def _generate_schedule(self, key: int, rounds: int) -> list:
        return [((key << r) | (key >> (8 - r))) & 0xFF for r in range(rounds + 1)]

    def encrypt(self, text: str, key: int, rounds: int) -> list:
        if not text: return []
        state = [ord(c) & 0xFF for c in text]
        subkeys = self._generate_schedule(key, rounds)
        
        state = self._key_mixing(state, subkeys[0])
        for r in range(1, rounds):
            state = self._sub_bytes(state, inv=False)
            state = self._shift_rows(state, inv=False)
            state = self._key_mixing(state, subkeys[r])
            
        state = self._sub_bytes(state, inv=False)
        state = self._key_mixing(state, subkeys[rounds])
        return state

    def decrypt(self, cipher_bytes: list, key: int, rounds: int) -> str:
        if not cipher_bytes: return ""
        state = list(cipher_bytes)
        subkeys = self._generate_schedule(key, rounds)
        
        state = self._key_mixing(state, subkeys[rounds])
        state = self._sub_bytes(state, inv=True)
        
        for r in range(rounds - 1, 0, -1):
            state = self._key_mixing(state, subkeys[r])
            state = self._shift_rows(state, inv=True)
            state = self._sub_bytes(state, inv=True)
            
        state = self._key_mixing(state, subkeys[0])
        return "".join(chr(b) for b in state if 32 <= b <= 126)


class ToolkitApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BIT4138 Advanced Crypto UI")
        # Explicitly avoiding invalid geometry specifiers to ensure stable startup
        self.geometry("760x600")
        self.engine = AESInspiredEngine()
        self._init_ui()

    def _init_ui(self):
        nb = ttk.Notebook(self)
        nb.pack(fill='both', expand=True, padx=8, pady=8)

        # Tab 1 workspace setup
        t1 = ttk.Frame(nb)
        nb.add(t1, text="Cipher Engine")

        p_frame = ttk.LabelFrame(t1, text=" Configurations ")
        p_frame.pack(fill='x', padx=10, pady=5)

        ttk.Label(p_frame, text="Key (Hex):").grid(row=0, column=0, padx=5, pady=5)
        self.ent_key = ttk.Entry(p_frame, width=8)
        self.ent_key.insert(0, "A5")
        self.ent_key.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(p_frame, text="Rounds:").grid(row=0, column=2, padx=10, pady=5)
        self.cb_rounds = ttk.Combobox(p_frame, values=["2", "4", "8", "12"], width=5, state="readonly")
        self.cb_rounds.set("4")
        self.cb_rounds.grid(row=0, column=3, padx=5, pady=5)

        ttk.Label(t1, text="Input Text:").pack(anchor='w', padx=10)
        self.txt_in = tk.Text(t1, height=4, width=60)
        self.txt_in.insert("1.0", "Testing Stable Mainloop Execution")
        self.txt_in.pack(fill='x', padx=10, pady=5)

        b_frame = ttk.Frame(t1)
        b_frame.pack(fill='x', padx=10, pady=5)
        ttk.Button(b_frame, text="🔒 Encrypt", command=self._enc_handler).pack(side='left', expand=True, fill='x', padx=2)
        ttk.Button(b_frame, text="🔓 Decrypt", command=self._dec_handler).pack(side='left', expand=True, fill='x', padx=2)

        ttk.Label(t1, text="Output Hex Stream:").pack(anchor='w', padx=10)
        self.txt_out = tk.Text(t1, height=4, width=60)
        self.txt_out.pack(fill='x', padx=10, pady=5)

        # Tab 2 workspace setup
        t2 = ttk.Frame(nb)
        nb.add(t2, text="Security Auditor")
        
        ttk.Button(t2, text="📊 Run Diagnostics & Output Security Report", command=self._run_diagnostics).pack(pady=40, ipadx=10, ipady=5)

    def _parse_params(self):
        try:
            return int(self.ent_key.get(), 16) & 0xFF, int(self.cb_rounds.get())
        except ValueError:
            messagebox.showerror("Error", "Invalid hex key configuration detected.")
            return None, None

    def _enc_handler(self):
        k, r = self._parse_params()
        if k is None: return
        pt = self.txt_in.get("1.0", "end-1c")
        ct_bytes = self.engine.encrypt(pt, k, r)
        self.txt_out.delete("1.0", "end")
        self.txt_out.insert("1.0", "".join(f"{b:02x}" for b in ct_bytes))

    def _dec_handler(self):
        k, r = self._parse_params()
        if k is None: return
        hex_str = self.txt_out.get("1.0", "end-1c").strip()
        try:
            bytes_list = [int(hex_str[i:i+2], 16) for i in range(0, len(hex_str), 2)]
            pt = self.engine.decrypt(bytes_list, k, r)
            self.txt_in.delete("1.0", "end")
            self.txt_in.insert("1.0", pt)
        except Exception:
            messagebox.showerror("Error", "Invalid hex format sequence.")

    def _run_diagnostics(self):
        k, r = self._parse_params()
        if k is None: return
        
        p1, p2 = "Crypto101", "Crypto100"
        c1 = self.engine.encrypt(p1, k, r)
        c2 = self.engine.encrypt(p2, k, r)
        
        total_bits = len(c1) * 8
        final_flips = sum(bin(b1 ^ b2).count('1') for b1, b2 in zip(c1, c2))
        avalanche_ratio = (final_flips / total_bits) * 100 if total_bits > 0 else 0
        
        print("\n" + "="*65)
        print("          CRYPTANALYSIS TOOLKIT DIAGNOSTIC DASHBOARD             ")
        print("="*65)
        print(f" [*] Input Vector 1 Delta Base: {p1}")
        print(f" [*] Input Vector 2 Delta Shift: {p2}")
        print(f" [*] Total Block Evaluation Bounds: {total_bits} Bits Analyzed")
        print(f" [*] Active Bits Mutated via S-Box Layers: {final_flips}")
        print(f" [*] Calculated Avalanche Metric Ratio: {avalanche_ratio:.2f}%")
        print("-" * 65)
        print(" STATUS: MAINLOOP STABLE | PERFORMANCE AUDIT TERMINATED CLEANLY")
        print("="*65 + "\n")
        messagebox.showinfo("Success", "Diagnostic metrics have been printed safely to the VS Code terminal!")

if __name__ == "__main__":
    app = ToolkitApp()
    app.mainloop()