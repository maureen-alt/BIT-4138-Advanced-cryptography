# week6_task1_spn.py

class SimpleSPN:
    def __init__(self):
        # 4-bit S-Box Lookup Table (Source doc example mapping)
        self.sbox = {
            0x0: 0xE, 0x1: 0x4, 0x2: 0xD, 0x3: 0x1,
            0x4: 0x2, 0x5: 0xF, 0x6: 0xB, 0x7: 0x8,
            0x8: 0x3, 0x9: 0xA, 0xA: 0x6, 0xB: 0xC,
            0xC: 0x5, 0xD: 0x9, 0xE: 0x0, 0xF: 0x7
        }
        # P-Box Permutation Mapping (Swaps upper and lower 4-bit chunks)
        self.pbox = [4, 5, 6, 7, 0, 1, 2, 3]

    def substitute(self, byte_value: int) -> int:
        """Splits byte into two 4-bit nibbles and applies S-Box lookup."""
        upper_nibble = (byte_value >> 4) & 0x0F
        lower_nibble = byte_value & 0x0F
        
        sub_upper = self.sbox[upper_nibble]
        sub_lower = self.sbox[lower_nibble]
        
        return (sub_upper << 4) | sub_lower

    def permute(self, byte_value: int) -> int:
        """Rearranges the bit positions based on the P-Box array layout."""
        permuted_byte = 0
        for original_pos, target_pos in enumerate(self.pbox):
            bit = (byte_value >> (7 - original_pos)) & 1
            permuted_byte |= (bit << (7 - target_pos))
        return permuted_byte

    def encrypt(self, plaintext: str) -> str:
        """Runs one full round of SPN encryption over the text string."""
        ciphertext_hex = []
        for char in plaintext:
            byte_val = ord(char)
            # Step 1: Substitution
            sub_val = self.substitute(byte_val)
            # Step 2: Permutation
            perm_val = self.permute(sub_val)
            ciphertext_hex.append(f"{perm_val:02x}")
        return "".join(ciphertext_hex)

# --- Execution block ---
if __name__ == "__main__":
    print("--- Week 6: Practical Task 1 (Basic SPN Design) ---")
    spn = SimpleSPN()
    user_data = input("Enter plain text string to encrypt: ")
    encrypted_result = spn.encrypt(user_data)
    print(f"Resulting Ciphertext (Hexadecimal): {encrypted_result}")