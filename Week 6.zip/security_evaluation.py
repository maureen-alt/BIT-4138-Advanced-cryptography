"""
BIT4138: Advanced Cryptography
SPN Cipher Suite - Automated Security Evaluation Engine
Measures: Strict Avalanche Criterion (SAC), Frequency Uniformity, and Bit Bias Metrics.
"""

import random

class EvaluatedSPNCipher:
    def __init__(self):
        # Standard 4-bit non-linear S-Box mapping to create confusion
        self.sbox = {
            0x0: 0xE, 0x1: 0x4, 0x2: 0xD, 0x3: 0x1,
            0x4: 0x2, 0x5: 0xF, 0x6: 0xB, 0x7: 0x8,
            0x8: 0x3, 0x9: 0xA, 0xA: 0x6, 0xB: 0xC,
            0xC: 0x5, 0xD: 0x9, 0xE: 0x0, 0xF: 0x7
        }
        # 8-bit position permutation list to achieve diffusion
        self.pbox = [4, 5, 6, 7, 0, 1, 2, 3]

    def _sub_bytes(self, state: list) -> list:
        """Applies the 4-bit S-Box mapping split across upper and lower nibbles of each byte."""
        output = []
        for byte in state:
            upper_nibble = (byte >> 4) & 0x0F
            lower_nibble = byte & 0x0F
            substituted = (self.sbox[upper_nibble] << 4) | self.sbox[lower_nibble]
            output.append(substituted)
        return output

    def _permute_bits(self, state: list) -> list:
        """Performs a structural bit-level transposition across byte pairs."""
        # Process bytes in 2-byte blocks (16-bit blocks) to ensure full diffusion
        output = list(state)
        for i in range(0, len(state) - 1, 2):
            block_16bit = (state[i] << 8) | state[i+1]
            permuted_16bit = 0
            # Map bits using a 16-bit extension of our P-Box routing rule
            for target_pos, source_pos in enumerate(self.pbox * 2):
                if (block_16bit & (1 << source_pos)):
                    permuted_16bit |= (1 << target_pos)
            output[i] = (permuted_16bit >> 8) & 0xFF
            output[i+1] = permuted_16bit & 0xFF
        return output

    def encrypt(self, plaintext: str, key: int, rounds: int) -> list:
        """Runs the SPN cipher loop across multiple rounds with key mixing."""
        state = [ord(char) & 0xFF for char in plaintext]
        
        # Ensure block length is even for 16-bit P-Box evaluation boundaries
        if len(state) % 2 != 0:
            state.append(0x00)

        for r in range(rounds):
            # 1. Key Mixing Layer (XOR)
            round_key = (key + r) & 0xFF
            state = [b ^ round_key for b in state]
            
            # 2. Substitution Layer (Confusion)
            state = self._sub_bytes(state)
            
            # 3. Permutation Layer (Diffusion)
            if r < rounds - 1:  # Omit permutation in the final round to mimic AES/DES architectures
                state = self._permute_bits(state)
                
        return state


class SPNSecurityEvaluator:
    @staticmethod
    def test_strict_avalanche_criterion(cipher, rounds: int):
        """
        Evaluates the Strict Avalanche Criterion (SAC).
        Flips exactly 1 bit in the plaintext and counts how many bits flip in the ciphertext.
        Ideal target: 50% change.
        """
        base_plaintext = "Crypto101"
        key = 0xA5
        
        # Establish the base ciphertext vector
        base_cipher = cipher.encrypt(base_plaintext, key, rounds)
        
        # Mutate precisely 1 bit within the trailing text character ('1' -> '0')
        mutated_plaintext = "Crypto100" 
        mutated_cipher = cipher.encrypt(mutated_plaintext, key, rounds)
        
        total_bits = len(base_cipher) * 8
        flipped_bits = sum(bin(b1 ^ b2).count('1') for b1, b2 in zip(base_cipher, mutated_cipher))
        avalanche_ratio = (flipped_bits / total_bits) * 100
        
        return total_bits, flipped_bits, avalanche_ratio

    @staticmethod
    def test_linear_statistical_bias(cipher, rounds: int):
        """
        Calculates the linear statistical bias properties of the output space.
        Bias = | (Count of 1s / Total Bits) - 0.5 |
        An ideal cipher should show a bias of ~0.0. Higher scores mean weaker security.
        """
        # Generate a continuous stream of random test frames
        sample_size = 500
        combined_bits_one = 0
        total_bits_evaluated = 0
        key = 0xA5

        for i in range(sample_size):
            mock_text = f"SampleBlock_{i:04d}"
            ciphertext = cipher.encrypt(mock_text, key, rounds)
            for byte in ciphertext:
                combined_bits_one += bin(byte).count('1')
                total_bits_evaluated += 8

        prob_ones = combined_bits_one / total_bits_evaluated
        statistical_bias = abs(prob_ones - 0.5)
        return statistical_bias


if __name__ == "__main__":
    # Instantiate the cipher instance
    spn_cipher = EvaluatedSPNCipher()
    
    print("\n" + "="*75)
    print("             SPN ENCRYPTION ENGINE SYSTEM SECURITY REPORT              ")
    print("="*75)
    print(f"{'Execution Rounds':<18}{'Total Bits':<15}{'Bits Flipped':<16}{'Avalanche %':<15}{'Linear Bias'}")
    print("-" * 75)

    # Evaluate how security profiles grow across different round levels
    for testing_round in [1, 2, 4, 8]:
        t_bits, f_bits, av_ratio = SPNSecurityEvaluator.test_strict_avalanche_criterion(spn_cipher, testing_round)
        bias = SPNSecurityEvaluator.test_linear_statistical_bias(spn_cipher, testing_round)
        
        # Formatting hex and integer layout values safely within padding rules
        print(f"Round {testing_round:02d} Matrix     {t_bits:<15}{f_bits:<16}{av_ratio:<15.2f}%{bias:.5f}")

    print("-" * 75)
    print(" EVALUATION MATRIX SUMMARY:")
    print("  [✓] Strict Avalanche Criterion (SAC) Target: 50.00%")
    print("  [✓] Ideal Linear Bias Target Threshold    : 0.00000")
    print("="*75 + "\n")