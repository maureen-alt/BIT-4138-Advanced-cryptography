# week6_advanced_spn.py
"""
BIT4138: Advanced Cryptography
Advanced Programming Task: Multi-round 8-bit SPN with Avalanche Demonstration
"""

import random

class AdvancedSPNCipher:
    def __init__(self, master_key: int = 0xAB, rounds: int = 4):
        """
        Initializes an Advanced 8-bit SPN Block Cipher.
        """
        self.rounds = rounds
        self.master_key = master_key & 0xFF  # Ensure key fits in 1 byte
        
        # 1. Larger 8-bit S-Box (0-255 mapping) using a pseudo-random lookup array 
        # based on a fixed seed to guarantee unique, invertible outputs.
        state_generator = random.Random(42)  # Fixed seed for consistency
        self.sbox = list(range(256))
        state_generator.shuffle(self.sbox)
        
        # Derive the mathematical Inverse S-Box for Decryption
        self.sbox_inv = [self.sbox.index(x) for x in range(256)]
        
        # 2. 8-Bit P-Box Permutation Array (Rearranges individual bit positions)
        # Positions: 0  1  2  3  4  5  6  7
        self.pbox = [3, 5, 0, 7, 1, 4, 2, 6]
        self.pbox_inv = [self.pbox.index(i) for i in range(8)]

    def _generate_round_keys(self) -> list:
        """Derives custom unique subkeys for each round via circular bit rotation."""
        subkeys = []
        for r in range(self.rounds + 1):
            # Circular left shift by 'r' bits to vary the round keys
            rotated_key = ((self.master_key << r) | (self.master_key >> (8 - r))) & 0xFF
            subkeys.append(rotated_key)
        return subkeys

    def _key_mixing(self, state: int, round_key: int) -> int:
        """Applies bitwise XOR between the data state and the round key."""
        return state ^ round_key

    def _substitution(self, state: int, inverse: bool = False) -> int:
        """Applies the 8-bit large S-Box transformation layer."""
        lookup = self.sbox_inv if inverse else self.sbox
        return lookup[state]

    def _permutation(self, state: int, inverse: bool = False) -> int:
        """Rearranges bit architecture across the 8-bit block using the P-Box map."""
        mapping = self.pbox_inv if inverse else self.pbox
        permuted_state = 0
        for original_pos, target_pos in enumerate(mapping):
            bit = (state >> (7 - original_pos)) & 1
            permuted_state |= (bit << (7 - target_pos))
        return permuted_state

    def encrypt_block(self, plaintext_byte: int) -> int:
        """Executes full multi-round encryption on an 8-bit data block."""
        round_keys = self._generate_round_keys()
        state = plaintext_byte

        # Structural Rounds 1 to N-1
        for r in range(self.rounds - 1):
            state = self._key_mixing(state, round_keys[r])
            state = self._substitution(state)
            state = self._permutation(state)
        
        # Final Round (Omits the final permutation step per standard SPN/AES design)
        state = self._key_mixing(state, round_keys[self.rounds - 1])
        state = self._substitution(state)
        state = self._key_mixing(state, round_keys[self.rounds])  # Post-whitening key key-mix
        
        return state

    def encrypt_string(self, text: str) -> str:
        """Encrypts an entire string into a readable hexadecimal stream."""
        return "".join(f"{self.encrypt_block(ord(char)):02x}" for char in text)


def demonstrate_avalanche_effect():
    """
    Demonstrates the Avalanche Effect by modifying exactly 1 bit 
    of the input data and observing the propagation across ciphertext.
    """
    print("\n" + "="*60)
    print("DEMONSTRATING AVALANCHE EFFECT (ADVANCED PROGRAMMING TASK)")
    print("="*60)
    
    # Instantiate the cipher with a custom user key and 4 rounds
    custom_key = 0xD4 
    cipher = AdvancedSPNCipher(master_key=custom_key, rounds=4)
    
    # 1. Define two plaintexts that differ by exactly ONE bit
    p1_char = 'A'  # Binary: 01000001
    p2_char = 'B'  # Binary: 01000010
    
    byte1 = ord(p1_char)
    byte2 = ord(p2_char)
    
    input_xor = byte1 ^ byte2
    # Verify bit difference count
    bits_changed_input = bin(input_xor).count('1')
    
    # 2. Run both bytes through our Multi-Round, Large S-Box SPN Engine
    c1 = cipher.encrypt_block(byte1)
    c2 = cipher.encrypt_block(byte2)
    
    output_xor = c1 ^ c2
    bits_changed_output = bin(output_xor).count('1')
    
    # 3. Print analysis results
    print(f"Plaintext 1: '{p1_char}'  -> Binary: {byte1:08b} (Hex: {byte1:02x})")
    print(f"Plaintext 2: '{p2_char}'  -> Binary: {byte2:08b} (Hex: {byte2:02x})")
    print(f"Input Bit Difference: {bits_changed_input} bit flipped.")
    print("-" * 50)
    print(f"Ciphertext 1: -> Binary: {c1:08b} (Hex: {c1:02x})")
    print(f"Ciphertext 2: -> Binary: {c2:08b} (Hex: {c2:02x})")
    print(f"Output XOR Delta Pattern: {output_xor:08b}")
    print(f"Total Ciphertext Bits Flipped: {bits_changed_output} out of 8 bits!")
    
    # 4. Success Evaluation Criterion 
    avalanche_percentage = (bits_changed_output / 8) * 100
    print(f"Avalanche Propagation Metric: {avalanche_percentage:.1f}%")
    print("Conclusion: A tiny input shift yielded a radically different output sequence!")
    print("="*60 + "\n")


if __name__ == "__main__":
    print("--- Week 6: Running Advanced SPN Implementation ---")
    
    # Simple String Run with Custom Parameters
    user_key = 0x5F
    user_rounds = 6
    advanced_spn = AdvancedSPNCipher(master_key=user_key, rounds=user_rounds)
    
    sample_text = "SPN"
    encrypted_hex = advanced_spn.encrypt_string(sample_text)
    
    print(f"Custom Master Key   : Hex {user_key:02x}")
    print(f"Configured Rounds  : {user_rounds}")
    print(f"Plaintext String    : {sample_text}")
    print(f"Generated Cipher    : {encrypted_hex}")
    
    # Execute the requested Avalanche Demonstration
    demonstrate_avalanche_effect()